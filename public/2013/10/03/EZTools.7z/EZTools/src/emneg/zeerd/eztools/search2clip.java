package emneg.zeerd.eztools;

import android.app.Activity;
import android.app.SearchManager;
import android.text.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class search2clip extends Activity{
	private ClipboardManager  mClipboard;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		String words = intent.getStringExtra(SearchManager.QUERY);
		Toast.makeText(getApplicationContext(), words, Toast.LENGTH_LONG).show();
		
		mClipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
		copyStyledText(words);
	}
	
	public void copyStyledText(String text) {
	    mClipboard.setText(text);
	}
}
