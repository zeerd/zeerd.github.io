/** Automatically generated file. DO NOT MODIFY */
package emneg.zeerd.webserver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}